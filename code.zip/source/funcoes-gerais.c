#include "../include/funcoes-gerais.h"

// Função que abre o arquivo e o coloca em uma struct com algumas flags
s_file_t *openfile(char *filename, char *openmode){
	s_file_t *file = (s_file_t *)malloc(1 * sizeof(s_file_t));
	file->fp = NULL;
	// Flag de arquivo vazio
	file->EmptyFile = '0';
	// Caso seja o stdin, admite-se ele para ler os registros
	if(strcmp(filename, "stdin") == 0){
		file->fp = stdin;
	}
	// Caso aconteça falha ao abrir o arquivo
	else if(filename == NULL || !(file->fp = fopen(filename, openmode))){
		printf("Falha no processamento do arquivo.\n");
		free(file);
		return NULL;
	}
	if(strcmp(filename, "stdin") != 0){
		fread(&file->consistenciaDoArquivo, sizeof(char), 1, file->fp);
		if(file->consistenciaDoArquivo == '0'){
			printf("Falha no processamento do arquivo.\n");
			free(file);
			return NULL;
		}
 	}
	if(strcmp(filename, "stdin") != 0) fseek(file->fp, 0, SEEK_END);
	// Verifica se o arquivo está vazio
	if(ftell(file->fp) == 0 && strcmp(filename, "stdin") != 0){
		file->EmptyFile = '1';
	}
	if(strcmp(filename, "stdin") != 0) fseek(file->fp, 0, SEEK_SET);
	return file;
}
// Função que fecha o arquivo
void closefile(s_file_t *s_file){
	if(s_file != NULL){
		fclose(s_file->fp);
	}
	free(s_file);
}

void binarioNaTela(char *nomeArquivoBinario) { /* Você não precisa entender o código dessa função. */

	/* Use essa função para comparação no run.codes. Lembre-se de ter fechado (fclose) o arquivo anteriormente.
	*  Ela vai abrir de novo para leitura e depois fechar (você não vai perder pontos por isso se usar ela). */

	unsigned long i, cs;
	unsigned char *mb;
	size_t fl;
	FILE *fs;
	if(nomeArquivoBinario == NULL || !(fs = fopen(nomeArquivoBinario, "rb"))) {
		fprintf(stderr, "ERRO AO ESCREVER O BINARIO NA TELA (função binarioNaTela): não foi possível abrir o arquivo que me passou para leitura. Ele existe e você tá passando o nome certo? Você lembrou de fechar ele com fclose depois de usar?\n");
		return;
	}
	fseek(fs, 0, SEEK_END);
	fl = ftell(fs);
	fseek(fs, 0, SEEK_SET);
	mb = (unsigned char *) malloc(fl);
	fread(mb, 1, fl, fs);

	cs = 0;
	for(i = 0; i < fl; i++) {
		cs += (unsigned long) mb[i];
	}
	printf("%lf\n", (cs / (double) 100));
	free(mb);
	fclose(fs);
}

void scan_quote_string(char *str) {

	/*
	*	Use essa função para ler um campo string delimitado entre aspas (").
	*	Chame ela na hora que for ler tal campo. Por exemplo:
	*
	*	A entrada está da seguinte forma:
	*		nomeDoCampo "MARIA DA SILVA"
	*
	*	Para ler isso para as strings já alocadas str1 e str2 do seu programa, você faz:
	*		scanf("%s", str1); // Vai salvar nomeDoCampo em str1
	*		scan_quote_string(str2); // Vai salvar MARIA DA SILVA em str2 (sem as aspas)
	*
	*/

	char R;

	while((R = getchar()) != EOF && isspace(R)); // ignorar espaços, \r, \n...

	if(R == 'N' || R == 'n') { // campo NULO
		getchar(); getchar(); getchar(); // ignorar o "ULO" de NULO.
		strcpy(str, ""); // copia string vazia
	} else if(R == '\"') {
		if(scanf("%[^\"]", str) != 1) { // ler até o fechamento das aspas
			strcpy(str, "");
		}
		getchar(); // ignorar aspas fechando
	} else if(R != EOF){ // vc tá tentando ler uma string que não tá entre aspas! Fazer leitura normal %s então, pois deve ser algum inteiro ou algo assim...
		str[0] = R;
		scanf("%s", &str[1]);
	} else { // EOF
		strcpy(str, "");
	}
}


/* ---------------- EXTRA ----------------

OPCIONAL: dicas sobre scanf() e fscanf():

scanf("%[^,]", string) -> lê até encontrar o caractere ',', não incluindo o mesmo na leitura.

Exemplo de entrada: "Oi, esse é um exemplo."
Nesse caso, o scanf("%[^,]") tem como resultado a string "Oi";

scanf("%[^\"]", string) -> lê até encontrar o caractere '"', não incluindo o mesmo na leitura.
scanf("%[^\n]", string) -> lê até encontrar o fim da linha, não incluindo o '\n' na leitura.

scanf("%*c") --> lê um char e não guarda em nenhuma variável, como se tivesse ignorado ele

*/

